import java.util.HashMap;
import java.util.LinkedList;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.Semaphore;

/**
 * Class that implements the channel used by wizards and miners to communicate.
 */
public class CommunicationChannel {
	/**
	 * Creates a {@code CommunicationChannel} object.
	 */

	BlockingQueue<Message> minerMessage = new LinkedBlockingQueue<Message>();
	BlockingQueue<Message> wizardMessage = new LinkedBlockingQueue<Message>();
	static ConcurrentHashMap<String, Integer> rooms = new ConcurrentHashMap<String, Integer>();
	static ConcurrentHashMap<Long, LinkedList<Entry>> mesList = new ConcurrentHashMap<Long, LinkedList<Entry>>();
	class Entry {
		String toHash;
		Integer node;
		
		public Entry (String toHash, Integer node) {
			this.toHash = toHash;
			this.node = node;
		}
		
//		@Override
//		public boolean equals(Object o) {
//			if (!(o instanceof Entry)) { 
//	            return false; 
//	        } else return id == ((Entry)o).id;
//		}
		
	}
	Vector<Entry> parents = new Vector<Entry>(10, 10);

	public CommunicationChannel() {
	}

	/**
	 * Puts a message on the miner channel (i.e., where miners write to and wizards
	 * read from).
	 * 
	 * @param message
	 *            message to be put on the channel
	 */
	
	public boolean wizHasMes() {
		return wizardMessage.size() != 0;
	}
	
	public void putMessageMinerChannel(Message message) {
//		String []parts = message.getData().split("#");
//		rooms.remove(parts[1]);
//		message.setData(parts[0]);
		//System.out.println("-Miner " + Thread.currentThread().getId() + " sends " + message.getCurrentRoom() + " " + message.getParentRoom() + " " + message.getData());
		minerMessage.add(message);
	}

	/**
	 * Gets a message from the miner channel (i.e., where miners write to and
	 * wizards read from).
	 * 
	 * @return message from the miner channel
	 */
	public Message getMessageMinerChannel() {
		try {
			return minerMessage.take();
		} catch (InterruptedException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Puts a message on the wizard channel (i.e., where wizards write to and miners
	 * read from).
	 * 
	 * @param message
	 *            message to be put on the channel
	 */
	public void putMessageWizardChannel(Message message) {
		//System.out.println("Wizard " + Thread.currentThread().getId() + " about to send  " + " " + message.getParentRoom() + " " + message.getCurrentRoom() + " " + message.getData());
		
		if (message.getData() == Wizard.EXIT) {
			wizardMessage.add(message);
			return;
		}
		
		if (message.getData() == Wizard.END) {
			while (mesList.get(Thread.currentThread().getId()).size() != 0) {
				Entry currRoom = mesList.get(Thread.currentThread().getId()).removeLast();
				Entry parRoom = mesList.get(Thread.currentThread().getId()).removeLast();
				if (rooms.putIfAbsent(currRoom.toHash, currRoom.node) != null)
					continue;
				wizardMessage.add(new Message(parRoom.node, currRoom.node, currRoom.toHash));
				//System.out.println("+Wizard " + Thread.currentThread().getId() + " sends " + parRoom.node + " " + currRoom.node + " " + currRoom.toHash);
			}
			return;
		}
		
		if (!mesList.containsKey(Thread.currentThread().getId())) {
			mesList.put(Thread.currentThread().getId(), new LinkedList<Entry>());
		}
		
		mesList.get(Thread.currentThread().getId()).add(new Entry(message.getData(), message.getCurrentRoom()));		
	}

	/**
	 * Gets a message from the wizard channel (i.e., where wizards write to and
	 * miners read from).
	 * 
	 * @return message from the miner channel
	 */
	public Message getMessageWizardChannel() {
		try {
			return wizardMessage.take();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
